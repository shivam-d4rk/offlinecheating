PYTHON AI ASSISTANT

Requirements: Windows 10/11 64-bit, 8 GB RAM recommended, ~3 GB free disk, internet for first setup.

1. Extract this ZIP.
2. Double-click install.bat.
3. Wait for Python, Ollama, dependencies and Qwen2.5-Coder 1.5B to install.
4. Press Ctrl+Shift+Space to show/hide the assistant.
5. Type a Python question or paste code; click Ask or press Ctrl+Enter.

The app sends prompts to Ollama at localhost:11434. No cloud API is used. Model quality is limited by its small size; verify important code. Do not paste passwords, API keys or private credentials.

Uninstall: close the app, uninstall Ollama/Python through Windows Settings > Apps if desired, then delete %LOCALAPPDATA%\PythonAI.
