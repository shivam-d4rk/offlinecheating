import threading
import customtkinter as ctk
from pynput import keyboard
import requests

MODEL = "qwen2.5-coder:1.5b"
API = "http://localhost:11434/api/chat"

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

class PythonAI:
    def __init__(self):
        self.root = ctk.CTk()
        self.root.title("Python AI Assistant")
        self.root.geometry("560x620")
        self.root.minsize(430, 460)
        self.root.attributes("-topmost", True)
        self.root.protocol("WM_DELETE_WINDOW", self.hide)
        self.visible, self.busy = True, False

        head = ctk.CTkFrame(self.root, fg_color="transparent")
        head.pack(fill="x", padx=16, pady=(14, 4))
        ctk.CTkLabel(head, text="Python AI", font=ctk.CTkFont(size=22, weight="bold")).pack(side="left")
        ctk.CTkLabel(head, text="LOCAL MODEL • OFFLINE", text_color="#82d9ad").pack(side="right")

        self.output = ctk.CTkTextbox(self.root, wrap="word", font=ctk.CTkFont(size=13))
        self.output.pack(fill="both", expand=True, padx=16, pady=10)
        self.output.insert("end", "Hi! I’m your local Python coding assistant.\nAsk me to explain Python, debug errors, or review code.\n\nShortcut: Ctrl + Shift + Space to show/hide.\n")
        self.output.configure(state="disabled")

        ctk.CTkLabel(self.root, text="Your question / Python code", anchor="w").pack(fill="x", padx=18)
        self.prompt = ctk.CTkTextbox(self.root, height=105, wrap="word")
        self.prompt.pack(fill="x", padx=16, pady=(4, 8))
        self.prompt.bind("<Control-Return>", lambda e: self.ask())

        foot = ctk.CTkFrame(self.root, fg_color="transparent")
        foot.pack(fill="x", padx=16, pady=(0, 14))
        self.status = ctk.CTkLabel(foot, text="Ready • qwen2.5-coder:1.5b", text_color="gray")
        self.status.pack(side="left")
        self.ask_btn = ctk.CTkButton(foot, text="Ask ↵", width=100, command=self.ask)
        self.ask_btn.pack(side="right")
        ctk.CTkButton(foot, text="Exit", width=65, fg_color="#6b3540", command=self.quit).pack(side="right", padx=8)

        self.listener = keyboard.GlobalHotKeys({'<ctrl>+<shift>+<space>': self.hotkey})
        self.listener.start()
        self.root.after(250, self.prompt.focus_set)

    def hotkey(self):
        self.root.after(0, self.toggle)

    def toggle(self):
        if self.visible:
            self.visible = False
            self.root.withdraw()
        else:
            self.visible = True
            self.root.deiconify()
            self.root.attributes("-topmost", True)
            self.root.lift()
            self.root.after(100, self.prompt.focus_set)

    def append(self, value):
        self.output.configure(state="normal")
        self.output.insert("end", value + "\n\n")
        self.output.see("end")
        self.output.configure(state="disabled")

    def ask(self):
        if self.busy:
            return
        question = self.prompt.get("1.0", "end").strip()
        if not question:
            return
        self.prompt.delete("1.0", "end")
        self.append("YOU\n" + question)
        self.busy = True
        self.ask_btn.configure(state="disabled")
        self.status.configure(text="Thinking locally...")
        threading.Thread(target=self.query_model, args=(question,), daemon=True).start()

    def query_model(self, question):
        try:
            data = {"model": MODEL, "stream": False, "messages": [
                {"role": "system", "content": "You are a practical Python programming tutor and debugger. Focus on Python. Explain simply, identify error causes, and show corrected code when useful. Never claim code was executed unless it was. Redirect unrelated questions to Python."},
                {"role": "user", "content": question}], "options": {"temperature": 0.2}}
            r = requests.post(API, json=data, timeout=300)
            r.raise_for_status()
            answer = r.json().get("message", {}).get("content", "No response received.")
        except requests.exceptions.ConnectionError:
            answer = "Cannot connect to Ollama at localhost:11434. Check that Ollama is running."
        except Exception as exc:
            answer = "Error: " + str(exc)
        self.root.after(0, lambda: self.finish(answer))

    def finish(self, answer):
        self.append("PYTHON AI\n" + answer)
        self.busy = False
        self.ask_btn.configure(state="normal")
        self.status.configure(text="Ready • local model")

    def quit(self):
        self.listener.stop()
        self.root.destroy()

    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    PythonAI().run()
