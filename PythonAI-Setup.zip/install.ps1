$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$root = $PSScriptRoot
$installDir = Join-Path $env:LOCALAPPDATA "PythonAI"
New-Item -ItemType Directory -Force -Path $installDir | Out-Null

function Download-File($url, $dest) {
  Write-Host "Downloading $([IO.Path]::GetFileName($dest)) ..." -ForegroundColor Cyan
  Invoke-WebRequest -Uri $url -OutFile $dest
}
$pythonCmd = Get-Command py -ErrorAction SilentlyContinue
if (-not $pythonCmd) {
  $pythonCmd = Get-Command python -ErrorAction SilentlyContinue
}
if (-not $pythonCmd) {
  $pyInstaller = Join-Path $env:TEMP "python-3.11.9-amd64.exe"
  Download-File "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe" $pyInstaller
  $p = Start-Process -FilePath $pyInstaller -ArgumentList "/quiet InstallAllUsers=0 PrependPath=1 Include_pip=1 Include_launcher=1" -Wait -PassThru
  if ($p.ExitCode -ne 0) { throw "Python installer failed: $($p.ExitCode)" }
  $pythonExe = Join-Path $env:LOCALAPPDATA "Programs\Python\Python311\python.exe"
  if (-not (Test-Path $pythonExe)) { throw "Python installed but was not found. Restart Windows and rerun installer." }
} else {
  if ($pythonCmd.Name -eq "py.exe") { $pythonExe = (Get-Command python -ErrorAction SilentlyContinue).Source }
  else { $pythonExe = $pythonCmd.Source }
}
if (-not $pythonExe -or -not (Test-Path $pythonExe)) { throw "Could not locate Python." }

$ollamaCmd = Get-Command ollama -ErrorAction SilentlyContinue
if ($ollamaCmd) { $ollamaExe = $ollamaCmd.Source }
else {
  $ollamaInstaller = Join-Path $env:TEMP "OllamaSetup.exe"
  Download-File "https://ollama.com/download/OllamaSetup.exe" $ollamaInstaller
  Start-Process -FilePath $ollamaInstaller -Wait
  $ollamaExe = Join-Path $env:LOCALAPPDATA "Programs\Ollama\ollama.exe"
  if (-not (Test-Path $ollamaExe)) {
    $ollamaCmd = Get-Command ollama -ErrorAction SilentlyContinue
    if ($ollamaCmd) { $ollamaExe = $ollamaCmd.Source } else { throw "Ollama was not detected. Install it from ollama.com/download/windows and rerun." }
  }
}

Write-Host "Installing Python packages..." -ForegroundColor Cyan
& $pythonExe -m pip install --upgrade pip
& $pythonExe -m pip install -r (Join-Path $root "requirements.txt")
if ($LASTEXITCODE -ne 0) { throw "Python dependencies failed to install." }

try { Invoke-RestMethod "http://localhost:11434/api/tags" -TimeoutSec 2 | Out-Null }
catch { Start-Process -FilePath $ollamaExe -ArgumentList "serve" -WindowStyle Hidden; Start-Sleep -Seconds 6 }

Write-Host "Downloading Qwen2.5-Coder 1.5B (roughly 1 GB)..." -ForegroundColor Cyan
& $ollamaExe pull qwen2.5-coder:1.5b
if ($LASTEXITCODE -ne 0) { throw "Model download failed. Check internet/disk space and rerun install.bat." }

Copy-Item (Join-Path $root "assistant.py") (Join-Path $installDir "assistant.py") -Force
$pythonw = Join-Path (Split-Path $pythonExe) "pythonw.exe"
if (-not (Test-Path $pythonw)) { $pythonw = $pythonExe }

$desktop = [Environment]::GetFolderPath("Desktop")
$ws = New-Object -ComObject WScript.Shell
$sc = $ws.CreateShortcut((Join-Path $desktop "Python AI Assistant.lnk"))
$sc.TargetPath = $pythonw
$sc.Arguments = "`"$installDir\assistant.py`""
$sc.WorkingDirectory = $installDir
$sc.Save()

Write-Host "INSTALLATION COMPLETE" -ForegroundColor Green
Write-Host "Desktop shortcut created. Launching assistant..."
Start-Process -FilePath $pythonw -ArgumentList "`"$installDir\assistant.py`""
