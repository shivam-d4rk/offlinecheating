@echo off
setlocal
title Python AI Assistant Installer
cd /d "%~dp0"
echo.
echo ===== PYTHON AI ASSISTANT INSTALLER =====
echo Internet is required for first-time setup.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
if errorlevel 1 (
  echo.
  echo Setup failed. Read the error above and try again.
  pause
  exit /b 1
)
echo.
echo Setup complete. Press any key to close.
pause
endlocal
