$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$root = $PSScriptRoot
$installDir = Join-Path $env:LOCALAPPDATA "PythonAI"
New-Item -ItemType Directory -Force -Path $installDir | Out-Null

function Download-File($url, $dest) {
    Write-Host "Downloading $([IO.Path]::GetFileName($dest)) ..." -ForegroundColor Cyan
    Invoke-WebRequest -Uri $url -OutFile $dest
}

# Resolve an actual Python executable, rather than assuming the "python" PATH alias exists.
$pythonExe = $null
$pyLauncher = Get-Command py.exe -ErrorAction SilentlyContinue
if ($pyLauncher) {
    $candidate = (& $pyLauncher.Source -3.11 -c "import sys; print(sys.executable)" 2>$null | Select-Object -Last 1)
    if ($candidate -and (Test-Path $candidate.Trim())) { $pythonExe = $candidate.Trim() }
}
if (-not $pythonExe) {
    $pythonCmd = Get-Command python.exe -ErrorAction SilentlyContinue
    if ($pythonCmd) {
        $candidate = (& $pythonCmd.Source -c "import sys; print(sys.executable)" 2>$null | Select-Object -Last 1)
        if ($candidate -and (Test-Path $candidate.Trim())) { $pythonExe = $candidate.Trim() }
    }
}

# Install a known Python version if no usable Python 3.11 was found.
if (-not $pythonExe) {
    $pyInstaller = Join-Path $env:TEMP "python-3.11.9-amd64.exe"
    Download-File "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe" $pyInstaller
    Write-Host "Installing Python 3.11 for the current Windows user..." -ForegroundColor Cyan
    $p = Start-Process -FilePath $pyInstaller -ArgumentList "/quiet InstallAllUsers=0 PrependPath=1 Include_pip=1 Include_launcher=1" -Wait -PassThru
    if ($p.ExitCode -ne 0) { throw "Python installer failed with exit code $($p.ExitCode)." }

    $pythonExe = Join-Path $env:LOCALAPPDATA "Programs\Python\Python311\python.exe"
    if (-not (Test-Path $pythonExe)) {
        # Check the Python launcher after installation as a fallback.
        $pyLauncher = Get-Command py.exe -ErrorAction SilentlyContinue
        if ($pyLauncher) {
            $candidate = (& $pyLauncher.Source -3.11 -c "import sys; print(sys.executable)" 2>$null | Select-Object -Last 1)
            if ($candidate -and (Test-Path $candidate.Trim())) { $pythonExe = $candidate.Trim() }
        }
    }
    if (-not $pythonExe -or -not (Test-Path $pythonExe)) {
        throw "Python installation finished, but python.exe was not found. Restart Windows and run install.bat again."
    }
}

Write-Host "Using Python: $pythonExe" -ForegroundColor Green

# Install Ollama if needed.
$ollamaCmd = Get-Command ollama.exe -ErrorAction SilentlyContinue
if ($ollamaCmd) {
    $ollamaExe = $ollamaCmd.Source
} else {
    $ollamaInstaller = Join-Path $env:TEMP "OllamaSetup.exe"
    Download-File "https://ollama.com/download/OllamaSetup.exe" $ollamaInstaller
    Write-Host "Installing Ollama..." -ForegroundColor Cyan
    Start-Process -FilePath $ollamaInstaller -Wait
    $possible = @(
        (Join-Path $env:LOCALAPPDATA "Programs\Ollama\ollama.exe"),
        (Join-Path $env:ProgramFiles "Ollama\ollama.exe")
    )
    $ollamaExe = $possible | Where-Object { Test-Path $_ } | Select-Object -First 1
    if (-not $ollamaExe) {
        $ollamaCmd = Get-Command ollama.exe -ErrorAction SilentlyContinue
        if ($ollamaCmd) { $ollamaExe = $ollamaCmd.Source }
    }
    if (-not $ollamaExe) { throw "Ollama was not detected after installation. Restart Windows and rerun install.bat." }
}

Write-Host "Installing assistant Python packages..." -ForegroundColor Cyan
& $pythonExe -m ensurepip --upgrade
if ($LASTEXITCODE -ne 0) { throw "Could not initialize pip." }
& $pythonExe -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw "Could not upgrade pip." }
& $pythonExe -m pip install -r (Join-Path $root "requirements.txt")
if ($LASTEXITCODE -ne 0) { throw "Python dependencies failed to install." }

# Start Ollama in the background if its local API is not already responding.
$ollamaReady = $false
try {
    Invoke-RestMethod "http://localhost:11434/api/tags" -TimeoutSec 3 | Out-Null
    $ollamaReady = $true
} catch {}
if (-not $ollamaReady) {
    Start-Process -FilePath $ollamaExe -ArgumentList "serve" -WindowStyle Hidden
    for ($i = 0; $i -lt 20; $i++) {
        Start-Sleep -Seconds 2
        try {
            Invoke-RestMethod "http://localhost:11434/api/tags" -TimeoutSec 2 | Out-Null
            $ollamaReady = $true
            break
        } catch {}
    }
}
if (-not $ollamaReady) { throw "Ollama service did not start. Restart Windows and rerun install.bat." }

Write-Host "Downloading Qwen2.5-Coder 1.5B model. This may take several minutes..." -ForegroundColor Cyan
& $ollamaExe pull qwen2.5-coder:1.5b
if ($LASTEXITCODE -ne 0) { throw "Model download failed. Check internet and disk space, then rerun install.bat." }

Copy-Item (Join-Path $root "assistant.py") (Join-Path $installDir "assistant.py") -Force
$pythonw = Join-Path (Split-Path $pythonExe) "pythonw.exe"
if (-not (Test-Path $pythonw)) { $pythonw = $pythonExe }

$desktop = [Environment]::GetFolderPath("Desktop")
$ws = New-Object -ComObject WScript.Shell
$sc = $ws.CreateShortcut((Join-Path $desktop "Python AI Assistant.lnk"))
$sc.TargetPath = $pythonw
$sc.Arguments = "`"$installDir\assistant.py`""
$sc.WorkingDirectory = $installDir
$sc.Save()

Write-Host ""
Write-Host "INSTALLATION COMPLETE" -ForegroundColor Green
Write-Host "Desktop shortcut created. Launching assistant..."
Start-Process -FilePath $pythonw -ArgumentList "`"$installDir\assistant.py`""
